<?php

define("USER", "root");
define("SERVER", "localhost");
define("BD", "proyecto");
define("PASS", "");
?>