
<!DOCTYPE html>
<html>
    <head>
        <title>Pugatech</title>
        <link rel="stylesheet" href="css/chat.css">
        <?php include "./inc/links.php"; ?>        
    </head>
    <body>   
        <?php include "./inc/navbar.php"; ?>

        <div class="container">
       
       <div class="chatbox">
               <div class="header">
                   <h4> <img src='img/perfil.jpg' class='imgRedonda'/> IT SUPPORT </h4>
                               
               </div>
               
                   <div class="body" id="chatbody">
                   <p class="alicia">Hola! soy IT SUPPORT, Estoy para responder preguntas relacionadas con lo basico de Soporte Tecnico. Espero poder ayudarte.</p>
                       <div class="scroller"></div>
                   </div>

               <form class="chat" method="post" autocomplete="off">
               
                           <div>
                               <input type="text" name="chat" id="chat" placeholder="Preguntale algo" style=" font-family: cursive; font-size: 20px;">
                           </div>
                           <div>
                            
                               <input type="submit" value="Enviar" id="btn">
                           </div>
               </form>
   </div>
</div>

<script src='js/app.js'></script>
   
        
    </body>
</html>
